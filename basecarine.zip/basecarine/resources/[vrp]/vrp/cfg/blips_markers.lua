local cfg = {}

cfg.blips = {
--[[	{ -1610.16,-823.47,12.04,357,38,"Garagem",0.4 },]]
}

return cfg