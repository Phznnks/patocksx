local cfg = {}

cfg.db = {
	driver = "oxmysql",
	host = "127.0.0.1",
	database = "vrp",
	user = "root",
	password = ""
}

return cfg