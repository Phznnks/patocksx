config = { }

config.Stock = ""  -- Webhook: Log Estoque de carros.
config.Whitelist = "" -- Webhook: Log Adição Whitelist.
config.UnWhitelist = "" -- Webhook: Log Remoção Whitelist.
config.Ban = "" -- Webhook: Log Adição Ban.
config.UnBan = "" -- Webhook: Log Remoção Ban.
config.Rename = "" -- Webhook: Log Renomear Jogador.
config.Addcar = "" -- Webhook: Log Adição Veiculo.
config.Remcar = "" -- Webhook: Log Remoção Veiculo.
config.Group = "" -- Webhook: Log Adição de Grupo.
config.staff = "" -- Webhook: Log Adição de Grupo.
config.UnGroup = "" -- Webhook: Log Remoção de Grupo.
config.Revive = "" -- Webhook: Log Reviver.
config.Kick = "" -- Webhook: Log Kick.
config.Fix = "" -- Webhook: Log Fix.
config.Nc = "https://discord.com/api/webhooks/1099272311602941983/tMwgcmCiGBEEdbnB9Z5yPVKeiqrIly6Zw9MPeKhwE3PzEbAamxCrgrUHbm3hZ_qyeHRf" -- Webhook: Log NoClip.
config.Tps = "" -- Webhook: Log Teleportes. (TPTO, TPTOME, TPALL...).
config.Org = "" -- Webhook: Log Contratação ou Demissão de Organizações.
config.Corno = "" -- Webhook: Log ID Visivel de ADM.
config.Status = "" -- Webhook: Log Registro Administrativo.

config.webhookIcon = ''
config.webhookBottomText = ''
config.webhookColor = 16431885