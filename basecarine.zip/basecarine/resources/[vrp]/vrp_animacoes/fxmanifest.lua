fx_version 'adamant'
game 'gta5'

client_scripts {
	'@vrp/lib/utils.lua',
	'tiodan_cl.lua'
}

server_scripts {
	'@vrp/lib/utils.lua',
	'tiodan_sv.lua'
}