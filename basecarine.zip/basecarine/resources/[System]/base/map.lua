spawnpoint 'mp_m_freemode_01' { x = -1038.16, y = -2738.70, z = 13.81 }

--