client_script "@ThnAC/natives.lua"
client_script "@vrp/lib/lib.lua" --Para remover esta pendencia de todos scripts, execute no console o comando "uninstall"

fx_version 'bodacious'
game 'gta5'

resource_type 'gametype' { name = 'VICE CITY V1' }

client_script 'fivem_client.lua'             

server_script 'fivem_server.lua'     