susurrando = {
	{ ['id'] = 1, ['x'] = -809.44, ['y'] = -1233.51, ['z'] = 7.33, ['distance'] = 50 }, -- Hospital
	{ ['id'] = 2, ['x'] = -581.65, ['y'] = -1062.52, ['z'] = 22.35, ['distance'] = 20 }, -- Cafe UwU
}
