shared_script '@wAC/client-side/library.lua'








fx_version 'bodacious'
game 'gta5'

client_scripts {
	'@vrp/lib/utils.lua',
	"config/*.lua",
	'client.lua',
}

server_scripts {
	'@vrp/lib/utils.lua',
	"config/*.lua",
	'server.lua',

}