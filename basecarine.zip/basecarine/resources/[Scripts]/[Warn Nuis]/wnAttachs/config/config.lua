webhook_garmas = ""

ListAttachs = {
	["WEAPON_SNSPISTOL"] = {
		Carregador = "COMPONENT_SNSPISTOL_CLIP_02",
	},
	["WEAPON_PISTOL_MK2"] = {
		Carregador = "COMPONENT_PISTOL_MK2_CLIP_02",
		Silenciador = "COMPONENT_AT_PI_SUPP_02",
		Compensador = "COMPONENT_AT_PI_COMP",
		Mira = "COMPONENT_AT_PI_RAIL",
	},
	["WEAPON_SPECIALCARBINE"] = {
		Carregador = "COMPONENT_CARBINERIFLE_CLIP_02",
		Silenciador = "COMPONENT_AT_AR_SUPP",
		Mira = "COMPONENT_AT_SCOPE_MEDIUM",
		Grip = "COMPONENT_AT_AR_AFGRIP",
	},
	["WEAPON_ASSAULTSMG"] = {
		Carregador = "COMPONENT_ASSAULTSMG_CLIP_02",
		Silenciador = "COMPONENT_AT_AR_SUPP_02",
		Mira = "COMPONENT_AT_SCOPE_MACRO",
	},
	["WEAPON_MICROSMG"] = {
		Carregador = "COMPONENT_MICROSMG_CLIP_02",
		Silenciador = "COMPONENT_AT_AR_SUPP_02",
		Mira = "COMPONENT_AT_SCOPE_MACRO",
	},
	["WEAPON_ASSAULTRIFLE"] = {
		Carregador = "COMPONENT_ASSAULTRIFLE_CLIP_02",
		Silenciador = "COMPONENT_AT_AR_SUPP_02",
		Mira = "COMPONENT_AT_SCOPE_MACRO",
		Grip = "COMPONENT_AT_AR_AFGRIP",
	},
}
