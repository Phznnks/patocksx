locs = {
	[1] = { 
		['Nome'] = "Joelheria",
		['x'] = -202.65, ['y'] = -736.89, ['z'] = 33.58,
		['Log'] = "",
		['Min'] = 15000,
		['Max'] = 35000,
		['Permissao'] = "joelheria.permissao"
	 },
	 [2] = { 
		['Nome'] = "Academia",
		['x'] = -177.26, ['y'] = -39.67, ['z'] = 52.13,
		['Log'] = "",
		['Min'] = 15000,
		['Max'] = 35000,
		['Permissao'] = "academia.permissao"
	 },
	 [3] = { 
		['Nome'] = "AutoEscola",
		['x'] = 227.27, ['y'] = 378.54, ['z'] = 106.12,
		['Log'] = "",
		['Min'] = 15000,
		['Max'] = 35000,
		['Permissao'] = "autoescola.permissao"
	 },
	 [4] = { 
		['Nome'] = "Restaurante",
		['x'] = -382.03, ['y'] = 264.93, ['z'] = 86.43,
		['Log'] = "",
		['Min'] = 15000,
		['Max'] = 35000,
		['Permissao'] = "restauranteempresa.permissao"
	 },
	 [5] = { 
		['Nome'] = "Entregas",
		['x'] = -428.95, ['y'] = -2788.54, ['z'] = 6.54,
		['Log'] = "",
		['Min'] = 15000,
		['Max'] = 35000,
		['Permissao'] = "entregas.permissao"
	 },
}